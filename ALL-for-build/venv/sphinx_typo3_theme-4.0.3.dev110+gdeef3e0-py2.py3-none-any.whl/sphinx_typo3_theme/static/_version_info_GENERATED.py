version_info = (
{
  "build_mtime": "1582033954",
  "module_name": "sphinx_typo3_theme",
  "version_scm": "4.0.3.dev110+gdeef3e0",
  "version_scm_build": "gdeef3e0",
  "version_scm_core": "4.0.3",
  "version_scm_pre_release": "dev110"
}
)

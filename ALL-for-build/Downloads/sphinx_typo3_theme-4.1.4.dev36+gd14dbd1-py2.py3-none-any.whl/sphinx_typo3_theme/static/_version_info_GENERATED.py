version_info = (
{
  "build_mtime": "1588774583",
  "module_name": "sphinx_typo3_theme",
  "version_scm": "4.1.4.dev36+gd14dbd1",
  "version_scm_build": "gd14dbd1",
  "version_scm_core": "4.1.4",
  "version_scm_pre_release": "dev36"
}
)

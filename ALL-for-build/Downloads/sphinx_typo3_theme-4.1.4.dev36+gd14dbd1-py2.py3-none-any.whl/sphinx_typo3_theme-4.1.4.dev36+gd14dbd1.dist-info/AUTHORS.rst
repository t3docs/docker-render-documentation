
=======
Authors
=======

sphinx_typo3_theme is written and maintained by Martin Bless
<martin.bless@mbless.de>.

Major developer is Benjamin Kott <benjamin.kott@outlook.com> who created the
whole frontend part from scratch and contributed workflows.

Other contributors, listed alphabetically, are:

*  ((some body -- thing contributed))
*  ((next one --- thing yet to come))

Many thanks for all contributions!
